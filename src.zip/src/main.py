import tkinter as tk
from tkinter import *
from pathlib import Path
from cat import Cat

born_path = Path('../assets')/'sprites'/'Born.png'
idle_path = Path('../assets')/'sprites'/'Idle2.png'
talk_path = Path('../assets')/'sprites'/'Walk.png'
sleep_path = Path('../assets')/'sprites'/'Sleep.png'


window = tk.Tk()
screen_width = window.winfo_screenwidth()  # 1536
screen_height = window.winfo_screenheight() # 864

window.title = 'VoidCat'
window.overrideredirect(True)
window.attributes("-topmost", True)
transparent_color = 'magenta'
window.configure(bg=transparent_color)
window.attributes('-transparentcolor', transparent_color)

cat = Cat(window, born_path, idle_path, talk_path, sleep_path)
window.geometry(f"{cat.window_width}x{cat.window_height}+{cat.x}+{cat.y}")


window.bind("<Escape>", lambda event: window.destroy())
window.mainloop()