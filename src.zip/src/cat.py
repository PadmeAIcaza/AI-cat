import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
import time

class Cat:
    def __init__(self, window, born_path, idle_path, talk_path, sleep_path):
        self.window = window
        self.window_width = 64
        self.window_height = 64
        self.frame_width = 32
        self.frame_height = 32
        self.width = self.frame_width
        self.height = self.frame_height
        self.x = 0
        self.y = 0
        self.state = 'idle'
        self.screen_width = self.window.winfo_screenwidth()
        self.animations = {}
        self.current_frame = 0
        self.animations['born'] = self.load_animation(born_path)
        self.animations['idle'] = self.load_animation(idle_path)
        self.animations['talk'] = self.load_animation(talk_path)
        self.animations['sleep'] = self.load_animation(sleep_path)
        self.current_animation = 'born'
        self.last_interaction = time.time()

        self.label = tk.Label(self.window, image=self.animations['born'][self.current_frame], bg="magenta", borderwidth=0)
        cat_x = (self.window_width - self.width) // 2
        cat_y = self.window_height - self.height
        self.label.place(x=cat_x, y=cat_y)

    def load_animation(self, path):
        # open sprite sheet using Pillow
        sprite_sheet = Image.open(path)
        frame_count = sprite_sheet.width // self.frame_width
        # holds every separate frame
        frames = []
        for index in range(frame_count):
            left = index * self.frame_width # frame 0 starts at x=0, frame 1 starts at x=64, frame 3 starts at x=128
            top = 0 # the sheet is only one row tall, so every frame starts at the top
            right = left + self.frame_width
            bottom = self.frame_height
            # crop ONE frame out of the sprite sheet
            frame = sprite_sheet.crop((left, top, right, bottom))
            # then convert it into a Tkinter image and store it
            frames.append(ImageTk.PhotoImage(frame))

        return frames

    def change_animation(self, animation_name):
        if self.current_animation == animation_name:
            return # avoids restarting the animation if it is already active

        self.current_animation = animation_name
        self.current_frame = 0

    def animate(self):
        # get the frames for the animation currenlty playing
        frames = self.animations[self.current_animation]
        # move to the next frame, when the last frame is reached, return to frame 0
        self.current_frame = (self.current_frame + 1) % len(frames)
        # update the image displayed by the label
        self.label.configure(image=frames[self.current_frame])

        self.window.after(150, self.animate)
